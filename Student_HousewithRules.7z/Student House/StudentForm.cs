﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_House
{
    public partial class StudentForm : Form
    {
        private StudentHouse sh;
        private LogIn li;
        private User u;
        public StudentForm(LogIn li, StudentHouse sh, User u)
        {
            InitializeComponent();
            this.sh = sh;
            this.li = li;
            this.u = u;
        }
        private void Back()
        {
            this.li.Show();
            this.Close();
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            try
            {
                this.Back();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
