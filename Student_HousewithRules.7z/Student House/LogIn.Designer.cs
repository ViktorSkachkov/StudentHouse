﻿namespace Student_House
{
    partial class LogIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogIn = new System.Windows.Forms.Button();
            this.btnSignUp = new System.Windows.Forms.Button();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.tbSurname = new System.Windows.Forms.TextBox();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lblSurname = new System.Windows.Forms.Label();
            this.lblLastName = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.tbFirstNameS = new System.Windows.Forms.TextBox();
            this.tbSurnameS = new System.Windows.Forms.TextBox();
            this.tbLastNameS = new System.Windows.Forms.TextBox();
            this.tbEmailS = new System.Windows.Forms.TextBox();
            this.tbPasswordS = new System.Windows.Forms.TextBox();
            this.lblFirst = new System.Windows.Forms.Label();
            this.lblSur = new System.Windows.Forms.Label();
            this.lblLast = new System.Windows.Forms.Label();
            this.lblPasswordS = new System.Windows.Forms.Label();
            this.lblEmailS = new System.Windows.Forms.Label();
            this.tbDeterminePassword = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnLogIn
            // 
            this.btnLogIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogIn.Location = new System.Drawing.Point(63, 417);
            this.btnLogIn.Name = "btnLogIn";
            this.btnLogIn.Size = new System.Drawing.Size(259, 94);
            this.btnLogIn.TabIndex = 0;
            this.btnLogIn.Text = "Log In";
            this.btnLogIn.UseVisualStyleBackColor = true;
            this.btnLogIn.Click += new System.EventHandler(this.btnLogIn_Click);
            // 
            // btnSignUp
            // 
            this.btnSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignUp.Location = new System.Drawing.Point(685, 417);
            this.btnSignUp.Name = "btnSignUp";
            this.btnSignUp.Size = new System.Drawing.Size(266, 94);
            this.btnSignUp.TabIndex = 1;
            this.btnSignUp.Text = "Sign Up";
            this.btnSignUp.UseVisualStyleBackColor = true;
            this.btnSignUp.Click += new System.EventHandler(this.btnSignUp_Click);
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(63, 39);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(259, 22);
            this.tbFirstName.TabIndex = 3;
            // 
            // tbSurname
            // 
            this.tbSurname.Location = new System.Drawing.Point(63, 109);
            this.tbSurname.Name = "tbSurname";
            this.tbSurname.Size = new System.Drawing.Size(259, 22);
            this.tbSurname.TabIndex = 4;
            // 
            // tbLastName
            // 
            this.tbLastName.Location = new System.Drawing.Point(63, 174);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(259, 22);
            this.tbLastName.TabIndex = 5;
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(63, 240);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(259, 22);
            this.tbEmail.TabIndex = 6;
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(63, 307);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(259, 22);
            this.tbPassword.TabIndex = 7;
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(60, 9);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(80, 17);
            this.lblFirstName.TabIndex = 8;
            this.lblFirstName.Text = "First Name:";
            // 
            // lblSurname
            // 
            this.lblSurname.AutoSize = true;
            this.lblSurname.Location = new System.Drawing.Point(60, 77);
            this.lblSurname.Name = "lblSurname";
            this.lblSurname.Size = new System.Drawing.Size(69, 17);
            this.lblSurname.TabIndex = 9;
            this.lblSurname.Text = "Surname:";
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(60, 145);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(80, 17);
            this.lblLastName.TabIndex = 10;
            this.lblLastName.Text = "Last Name:";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Location = new System.Drawing.Point(60, 275);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(73, 17);
            this.lblPassword.TabIndex = 11;
            this.lblPassword.Text = "Password:";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(60, 207);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(46, 17);
            this.lblEmail.TabIndex = 12;
            this.lblEmail.Text = "Email:";
            // 
            // tbFirstNameS
            // 
            this.tbFirstNameS.Location = new System.Drawing.Point(685, 39);
            this.tbFirstNameS.Name = "tbFirstNameS";
            this.tbFirstNameS.Size = new System.Drawing.Size(259, 22);
            this.tbFirstNameS.TabIndex = 3;
            // 
            // tbSurnameS
            // 
            this.tbSurnameS.Location = new System.Drawing.Point(685, 109);
            this.tbSurnameS.Name = "tbSurnameS";
            this.tbSurnameS.Size = new System.Drawing.Size(259, 22);
            this.tbSurnameS.TabIndex = 4;
            // 
            // tbLastNameS
            // 
            this.tbLastNameS.Location = new System.Drawing.Point(685, 174);
            this.tbLastNameS.Name = "tbLastNameS";
            this.tbLastNameS.Size = new System.Drawing.Size(259, 22);
            this.tbLastNameS.TabIndex = 5;
            // 
            // tbEmailS
            // 
            this.tbEmailS.Location = new System.Drawing.Point(685, 240);
            this.tbEmailS.Name = "tbEmailS";
            this.tbEmailS.Size = new System.Drawing.Size(259, 22);
            this.tbEmailS.TabIndex = 6;
            // 
            // tbPasswordS
            // 
            this.tbPasswordS.Location = new System.Drawing.Point(685, 307);
            this.tbPasswordS.Name = "tbPasswordS";
            this.tbPasswordS.Size = new System.Drawing.Size(259, 22);
            this.tbPasswordS.TabIndex = 7;
            // 
            // lblFirst
            // 
            this.lblFirst.AutoSize = true;
            this.lblFirst.Location = new System.Drawing.Point(682, 9);
            this.lblFirst.Name = "lblFirst";
            this.lblFirst.Size = new System.Drawing.Size(80, 17);
            this.lblFirst.TabIndex = 8;
            this.lblFirst.Text = "First Name:";
            // 
            // lblSur
            // 
            this.lblSur.AutoSize = true;
            this.lblSur.Location = new System.Drawing.Point(682, 77);
            this.lblSur.Name = "lblSur";
            this.lblSur.Size = new System.Drawing.Size(69, 17);
            this.lblSur.TabIndex = 9;
            this.lblSur.Text = "Surname:";
            // 
            // lblLast
            // 
            this.lblLast.AutoSize = true;
            this.lblLast.Location = new System.Drawing.Point(682, 145);
            this.lblLast.Name = "lblLast";
            this.lblLast.Size = new System.Drawing.Size(80, 17);
            this.lblLast.TabIndex = 10;
            this.lblLast.Text = "Last Name:";
            // 
            // lblPasswordS
            // 
            this.lblPasswordS.AutoSize = true;
            this.lblPasswordS.Location = new System.Drawing.Point(682, 275);
            this.lblPasswordS.Name = "lblPasswordS";
            this.lblPasswordS.Size = new System.Drawing.Size(73, 17);
            this.lblPasswordS.TabIndex = 11;
            this.lblPasswordS.Text = "Password:";
            // 
            // lblEmailS
            // 
            this.lblEmailS.AutoSize = true;
            this.lblEmailS.Location = new System.Drawing.Point(682, 207);
            this.lblEmailS.Name = "lblEmailS";
            this.lblEmailS.Size = new System.Drawing.Size(46, 17);
            this.lblEmailS.TabIndex = 12;
            this.lblEmailS.Text = "Email:";
            // 
            // tbDeterminePassword
            // 
            this.tbDeterminePassword.Location = new System.Drawing.Point(685, 378);
            this.tbDeterminePassword.Name = "tbDeterminePassword";
            this.tbDeterminePassword.Size = new System.Drawing.Size(259, 22);
            this.tbDeterminePassword.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(682, 341);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(314, 34);
            this.label1.TabIndex = 11;
            this.label1.Text = "Write a password to determine whether you want\r\n to create a student or an admin " +
    "account:";
            // 
            // LogIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1012, 523);
            this.Controls.Add(this.lblEmailS);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblPasswordS);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblLast);
            this.Controls.Add(this.lblLastName);
            this.Controls.Add(this.lblSur);
            this.Controls.Add(this.lblSurname);
            this.Controls.Add(this.tbDeterminePassword);
            this.Controls.Add(this.lblFirst);
            this.Controls.Add(this.tbPasswordS);
            this.Controls.Add(this.lblFirstName);
            this.Controls.Add(this.tbEmailS);
            this.Controls.Add(this.tbPassword);
            this.Controls.Add(this.tbLastNameS);
            this.Controls.Add(this.tbEmail);
            this.Controls.Add(this.tbSurnameS);
            this.Controls.Add(this.tbLastName);
            this.Controls.Add(this.tbFirstNameS);
            this.Controls.Add(this.tbSurname);
            this.Controls.Add(this.tbFirstName);
            this.Controls.Add(this.btnSignUp);
            this.Controls.Add(this.btnLogIn);
            this.Name = "LogIn";
            this.Text = "Log In Page";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLogIn;
        private System.Windows.Forms.Button btnSignUp;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.TextBox tbSurname;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblSurname;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox tbFirstNameS;
        private System.Windows.Forms.TextBox tbSurnameS;
        private System.Windows.Forms.TextBox tbLastNameS;
        private System.Windows.Forms.TextBox tbEmailS;
        private System.Windows.Forms.TextBox tbPasswordS;
        private System.Windows.Forms.Label lblFirst;
        private System.Windows.Forms.Label lblSur;
        private System.Windows.Forms.Label lblLast;
        private System.Windows.Forms.Label lblPasswordS;
        private System.Windows.Forms.Label lblEmailS;
        private System.Windows.Forms.TextBox tbDeterminePassword;
        private System.Windows.Forms.Label label1;
    }
}

