﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_House
{
    public class StudentHouse
    {
        private List<User> users;
        public StudentHouse()
        {
            this.users = new List<User>() { new User("Viktor", "Aleksandrov", "Skachkov", "viktor.skachkov01@gmail.com", "sulphur", "@student")};
        }
        public void AddUser(String firstName, String surname, String lastName, String email, String password, String determinePassword)
        {
            if (determinePassword != "@student" && determinePassword != "@admin")
            {
                throw new Exception("The password you have input to determine the type of your account is not correct! Try again!");
            }
            else
            {
                if (!this.CheckName(firstName, surname, lastName))
                {
                    if (!this.CheckEmail(email))
                    {
                        if (!this.CheckPassword(password))
                        {
                            this.users.Add(new User(firstName, surname, lastName, email, password, determinePassword));
                        }
                        else
                        {
                            throw new Exception("This password is already in use by another user!");
                        }
                    }
                    else
                    {
                        throw new Exception(String.Format("The email '{0}' is already in use by another user!", email));
                    }
                }
                else
                {
                    throw new Exception(String.Format("The name '{0} {1} {2}' is already in use by another user!", firstName, surname, lastName));
                }
            }
        }
        public bool LogIn(String firstName, String surname, String lastName, String email, String password)
        {
            if(this.CheckName(firstName, surname, lastName))
            {
                if (this.CheckEmail(email))
                {
                    if (this.CheckPassword(password))
                    {
                        return true;
                    }
                    else
                    {
                        throw new Exception("This password does not exist in the database!");
                    }
                }
                else
                {
                    throw new Exception(String.Format("The email '{0}' does not exist in the database!", email));
                }
            }
            else
            {
                throw new Exception(String.Format("The name '{0} {1} {2}' does not exist in the database!", firstName, surname, lastName));
            }
        }
        private bool CheckName(String firstName, String surname, String lastName)
        {
            if (this.users.Exists(x => x.FirstName == firstName) && this.users.Exists(x => x.Surname == surname)
                && this.users.Exists(x => x.LastName == lastName))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool CheckPassword(String password)
        {
            if(this.users.Exists(x => x.Password == password))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool CheckEmail(String email)
        {
            if(this.users.Exists(x => x.Email == email))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public User GetUser(String password)
        {
            User u = this.users.Find(x => x.Password == password);
            return u;
        }
    }
}
