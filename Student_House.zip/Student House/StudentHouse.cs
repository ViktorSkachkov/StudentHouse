﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_House
{
    public class StudentHouse
    {
        private List<User> users;
        public StudentHouse()
        {
            this.users = new List<User>() { new User(45454545, "Viktor", "Aleksandrov", "Skachkov", "viktor.skachkov01@gmail.com", "sulphur", "@student"),
                                            new User(98761234, "Johnny", "Brown", "Kerrigan", "j.kerriganY@gmail.com", "hydraSwimmer", "@student"),
                                            new User(66666666, "Pavel", "Ivanov", "Vasilov", "pav.vasilov999@gmail.com", "dragonrider", "@admin")};
        }
        public void AddUser(int userNumber, String firstName, String surname, String lastName, String email, String password, String determinePassword)
        {
            if (determinePassword != "@student" && determinePassword != "@admin")
            {
                
            }
            else
            {
                if (!this.CheckName(firstName, surname, lastName))
                {
                    if (!this.CheckEmail(email))
                    {
                        if (!this.CheckPassword(password))
                        {
                            this.users.Add(new User(userNumber, firstName, surname, lastName, email, password, determinePassword));
                        }
                        else
                        {
                            
                        }
                    }
                    else
                    {
                        
                    }
                }
                else
                {
                    
                }
            }
        }
        public bool CheckNumber(int userNumber)
        {
            if(this.users.Exists(x => x.UserNumber == userNumber))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool CheckName(String firstName, String surname, String lastName)
        {
            if (this.users.Exists(x => x.FirstName == firstName) && this.users.Exists(x => x.Surname == surname)
                && this.users.Exists(x => x.LastName == lastName))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool CheckPassword(String password)
        {
            if(this.users.Exists(x => x.Password == password))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        private bool CheckEmail(String email)
        {
            if(this.users.Exists(x => x.Email == email))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public User GetUser(int userNumber, String password)
        {
            User u = this.users.Find(x => x.Password == password &&  x.UserNumber == userNumber);
            return u;
        }
    }
}
