﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_House
{
    public partial class SignIn : Form
    {
        public SignIn()
        {
            InitializeComponent();
        }
        private List<User> users;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(tbFirstName.Text)&& !String.IsNullOrEmpty(tbSurname.Text)&& !String.IsNullOrEmpty(tbLastName.Text)&& !String.IsNullOrEmpty(tbEmail.Text)&& !String.IsNullOrEmpty(tbPassword.Text)&&
                !String.IsNullOrEmpty(tbPassword.Text))
            {
                string firstName = tbFirstName.Text.Trim();
                string surname = tbSurname.Text.Trim();
                string lastName = tbLastName.Text.Trim();
                string email = tbEmail.Text.Trim();
                string password = tbPassword.Text.Trim();
                string repeatPassword = tbPassword.Text.Trim();
                if (password == repeatPassword)
                {
                    this.users = new List<User>() { new User(123123123, firstName, surname, lastName, email, password, "@student", true) }; 
                }
                
            }
            //temporary variables
          
            
        }
    }
}
    