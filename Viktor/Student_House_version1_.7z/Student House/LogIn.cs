﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_House
{
    public partial class LogIn : Form
    {
        private StudentHouse sh;
        public LogIn()
        {
            InitializeComponent();
            this.sh = new StudentHouse();
        }
        private void Log()
        {
            String firstName = this.tbFirstName.Text.Trim();
            String surname = this.tbSurname.Text.Trim();
            String lastName = this.tbLastName.Text.Trim();
            String email = this.tbEmail.Text.Trim();
            String password = this.tbPassword.Text.Trim();
        }
        private void btnLogIn_Click(object sender, EventArgs e)
        {
            try
            {
                this.Log();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void Sign()
        {
            String firstName = this.tbFirstNameS.Text.Trim();
            String surname = this.tbSurnameS.Text.Trim();
            String lastName = this.tbLastNameS.Text.Trim();
            String email = this.tbEmailS.Text.Trim();
            String password = this.tbPasswordS.Text.Trim();
            String determinePassword = this.tbDeterminePassword.Text.Trim();
            this.sh.AddUser(firstName, surname, lastName, email, password, determinePassword);
            User u = this.sh.GetUser(password);
        }
        private void btnSignUp_Click(object sender, EventArgs e)
        {
            try
            {
                this.Sign();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
