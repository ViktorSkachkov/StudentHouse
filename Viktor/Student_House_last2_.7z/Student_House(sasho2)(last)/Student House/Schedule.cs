﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Student_House
{
    public class Schedule
    {
        private User student;
        private String day;
        private String status;
        private String activity;
        public Schedule(User u, String status, String activity)
        {
            this.student = u;
            this.status = status;
            this.activity = activity;
        }
        public Schedule(User u, String day, String status, String activity)
        {
            this.student = u;
            this.day = day;
            this.status = status;
            this.activity = activity;
        }
        public User Student
        {
            get { return this.student; }
            set { this.student = value; }
        }
        public String Day
        {
            get { return this.day; }
            set { this.day = value; }
        }
        public String Status
        {
            get { return this.status; }
            set { this.status = value; }
        }
        public String Activity
        {
            get { return this.activity; }
            set { this.activity = value; }
        }
        public String GetInfo()
        {
            String holder = "";
            if (status == "daily")
            {
                holder += String.Format("{0}: ", this.day);
            }
            holder = String.Format("The student {0} should {1}", this.student.FirstName, this.activity);
            return holder;
        }
    }
}
