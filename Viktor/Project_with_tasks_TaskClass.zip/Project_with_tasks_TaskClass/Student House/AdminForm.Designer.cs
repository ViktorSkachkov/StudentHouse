﻿namespace Student_House
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbRules = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label2 = new System.Windows.Forms.Label();
            this.lblEdit = new System.Windows.Forms.Label();
            this.tbEditRule = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.lbRules = new System.Windows.Forms.ListBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblRule = new System.Windows.Forms.Label();
            this.tbAddRule = new System.Windows.Forms.TextBox();
            this.tpPendingAccounts = new System.Windows.Forms.TabPage();
            this.label5 = new System.Windows.Forms.Label();
            this.tbBannAccounts = new System.Windows.Forms.TextBox();
            this.btnBann = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lbBanned = new System.Windows.Forms.ListBox();
            this.btnDenied = new System.Windows.Forms.Button();
            this.btnApprove = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbPending = new System.Windows.Forms.ListBox();
            this.tpTasks = new System.Windows.Forms.TabPage();
            this.lblThisWeek = new System.Windows.Forms.Label();
            this.lblSunday = new System.Windows.Forms.Label();
            this.lblSaturday = new System.Windows.Forms.Label();
            this.lblFriday = new System.Windows.Forms.Label();
            this.lblThursday = new System.Windows.Forms.Label();
            this.lblWednesday = new System.Windows.Forms.Label();
            this.lblTuesday = new System.Windows.Forms.Label();
            this.lblMonday = new System.Windows.Forms.Label();
            this.btnAssign = new System.Windows.Forms.Button();
            this.lblBack = new System.Windows.Forms.Label();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.tbRules.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tpPendingAccounts.SuspendLayout();
            this.tpTasks.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbRules
            // 
            this.tbRules.Controls.Add(this.tabPage1);
            this.tbRules.Controls.Add(this.tpPendingAccounts);
            this.tbRules.Controls.Add(this.tpTasks);
            this.tbRules.Location = new System.Drawing.Point(12, 57);
            this.tbRules.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbRules.Name = "tbRules";
            this.tbRules.SelectedIndex = 0;
            this.tbRules.Size = new System.Drawing.Size(1199, 546);
            this.tbRules.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.lblEdit);
            this.tabPage1.Controls.Add(this.tbEditRule);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.btnEdit);
            this.tabPage1.Controls.Add(this.btnRemove);
            this.tabPage1.Controls.Add(this.lbRules);
            this.tabPage1.Controls.Add(this.btnAdd);
            this.tabPage1.Controls.Add(this.lblRule);
            this.tabPage1.Controls.Add(this.tbAddRule);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(1191, 517);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Rules";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(437, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "The student house rules:";
            // 
            // lblEdit
            // 
            this.lblEdit.AutoSize = true;
            this.lblEdit.Location = new System.Drawing.Point(5, 304);
            this.lblEdit.Name = "lblEdit";
            this.lblEdit.Size = new System.Drawing.Size(114, 17);
            this.lblEdit.TabIndex = 9;
            this.lblEdit.Text = "Write a new rule:";
            // 
            // tbEditRule
            // 
            this.tbEditRule.Location = new System.Drawing.Point(9, 335);
            this.tbEditRule.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbEditRule.Name = "tbEditRule";
            this.tbEditRule.Size = new System.Drawing.Size(425, 22);
            this.tbEditRule.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 34);
            this.label1.TabIndex = 7;
            this.label1.Text = "Select a rule from the listbox \r\nto edit or remove";
            // 
            // btnEdit
            // 
            this.btnEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEdit.Location = new System.Drawing.Point(9, 363);
            this.btnEdit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(221, 71);
            this.btnEdit.TabIndex = 6;
            this.btnEdit.Text = "Edit";
            this.btnEdit.UseVisualStyleBackColor = true;
            this.btnEdit.Click += new System.EventHandler(this.btnEdit_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(9, 207);
            this.btnRemove.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(221, 71);
            this.btnRemove.TabIndex = 5;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // lbRules
            // 
            this.lbRules.FormattingEnabled = true;
            this.lbRules.ItemHeight = 16;
            this.lbRules.Location = new System.Drawing.Point(441, 46);
            this.lbRules.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lbRules.Name = "lbRules";
            this.lbRules.Size = new System.Drawing.Size(729, 388);
            this.lbRules.TabIndex = 4;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(9, 75);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(221, 57);
            this.btnAdd.TabIndex = 3;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblRule
            // 
            this.lblRule.AutoSize = true;
            this.lblRule.Location = new System.Drawing.Point(5, 14);
            this.lblRule.Name = "lblRule";
            this.lblRule.Size = new System.Drawing.Size(114, 17);
            this.lblRule.TabIndex = 2;
            this.lblRule.Text = "Write a new rule:";
            // 
            // tbAddRule
            // 
            this.tbAddRule.Location = new System.Drawing.Point(9, 47);
            this.tbAddRule.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbAddRule.Name = "tbAddRule";
            this.tbAddRule.Size = new System.Drawing.Size(425, 22);
            this.tbAddRule.TabIndex = 1;
            // 
            // tpPendingAccounts
            // 
            this.tpPendingAccounts.BackColor = System.Drawing.Color.Gainsboro;
            this.tpPendingAccounts.Controls.Add(this.label5);
            this.tpPendingAccounts.Controls.Add(this.tbBannAccounts);
            this.tpPendingAccounts.Controls.Add(this.btnBann);
            this.tpPendingAccounts.Controls.Add(this.button3);
            this.tpPendingAccounts.Controls.Add(this.button4);
            this.tpPendingAccounts.Controls.Add(this.label4);
            this.tpPendingAccounts.Controls.Add(this.lbBanned);
            this.tpPendingAccounts.Controls.Add(this.btnDenied);
            this.tpPendingAccounts.Controls.Add(this.btnApprove);
            this.tpPendingAccounts.Controls.Add(this.label3);
            this.tpPendingAccounts.Controls.Add(this.lbPending);
            this.tpPendingAccounts.Location = new System.Drawing.Point(4, 25);
            this.tpPendingAccounts.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpPendingAccounts.Name = "tpPendingAccounts";
            this.tpPendingAccounts.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpPendingAccounts.Size = new System.Drawing.Size(1191, 517);
            this.tpPendingAccounts.TabIndex = 1;
            this.tpPendingAccounts.Text = "Pending Accounts";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(604, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 17);
            this.label5.TabIndex = 23;
            this.label5.Text = "Student number ";
            // 
            // tbBannAccounts
            // 
            this.tbBannAccounts.Location = new System.Drawing.Point(719, 86);
            this.tbBannAccounts.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tbBannAccounts.Name = "tbBannAccounts";
            this.tbBannAccounts.Size = new System.Drawing.Size(111, 22);
            this.tbBannAccounts.TabIndex = 22;
            // 
            // btnBann
            // 
            this.btnBann.Location = new System.Drawing.Point(719, 123);
            this.btnBann.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnBann.Name = "btnBann";
            this.btnBann.Size = new System.Drawing.Size(111, 23);
            this.btnBann.TabIndex = 21;
            this.btnBann.Text = "Bann";
            this.btnBann.UseVisualStyleBackColor = true;
            this.btnBann.Click += new System.EventHandler(this.btnBann_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1069, 425);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 20;
            this.button3.Text = "Delete";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(867, 425);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 19;
            this.button4.Text = "Unbann";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(916, 66);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 17);
            this.label4.TabIndex = 18;
            this.label4.Text = "Banned accounts";
            // 
            // lbBanned
            // 
            this.lbBanned.FormattingEnabled = true;
            this.lbBanned.ItemHeight = 16;
            this.lbBanned.Location = new System.Drawing.Point(867, 86);
            this.lbBanned.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lbBanned.Name = "lbBanned";
            this.lbBanned.Size = new System.Drawing.Size(277, 324);
            this.lbBanned.TabIndex = 17;
            // 
            // btnDenied
            // 
            this.btnDenied.Location = new System.Drawing.Point(243, 425);
            this.btnDenied.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnDenied.Name = "btnDenied";
            this.btnDenied.Size = new System.Drawing.Size(75, 23);
            this.btnDenied.TabIndex = 16;
            this.btnDenied.Text = "Denied";
            this.btnDenied.UseVisualStyleBackColor = true;
            // 
            // btnApprove
            // 
            this.btnApprove.Location = new System.Drawing.Point(41, 425);
            this.btnApprove.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnApprove.Name = "btnApprove";
            this.btnApprove.Size = new System.Drawing.Size(75, 23);
            this.btnApprove.TabIndex = 15;
            this.btnApprove.Text = "Aproove";
            this.btnApprove.UseVisualStyleBackColor = true;
            this.btnApprove.Click += new System.EventHandler(this.btnApprove_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(89, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(114, 17);
            this.label3.TabIndex = 14;
            this.label3.Text = "Waiting approval";
            // 
            // lbPending
            // 
            this.lbPending.FormattingEnabled = true;
            this.lbPending.ItemHeight = 16;
            this.lbPending.Location = new System.Drawing.Point(41, 86);
            this.lbPending.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lbPending.Name = "lbPending";
            this.lbPending.Size = new System.Drawing.Size(277, 324);
            this.lbPending.TabIndex = 13;
            // 
            // tpTasks
            // 
            this.tpTasks.BackColor = System.Drawing.Color.Gainsboro;
            this.tpTasks.Controls.Add(this.lblThisWeek);
            this.tpTasks.Controls.Add(this.lblSunday);
            this.tpTasks.Controls.Add(this.lblSaturday);
            this.tpTasks.Controls.Add(this.lblFriday);
            this.tpTasks.Controls.Add(this.lblThursday);
            this.tpTasks.Controls.Add(this.lblWednesday);
            this.tpTasks.Controls.Add(this.lblTuesday);
            this.tpTasks.Controls.Add(this.lblMonday);
            this.tpTasks.Controls.Add(this.btnAssign);
            this.tpTasks.Location = new System.Drawing.Point(4, 25);
            this.tpTasks.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpTasks.Name = "tpTasks";
            this.tpTasks.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tpTasks.Size = new System.Drawing.Size(1191, 517);
            this.tpTasks.TabIndex = 2;
            this.tpTasks.Text = "Tasks";
            // 
            // lblThisWeek
            // 
            this.lblThisWeek.AutoSize = true;
            this.lblThisWeek.Location = new System.Drawing.Point(237, 473);
            this.lblThisWeek.Name = "lblThisWeek";
            this.lblThisWeek.Size = new System.Drawing.Size(21, 17);
            this.lblThisWeek.TabIndex = 8;
            this.lblThisWeek.Text = "8)";
            // 
            // lblSunday
            // 
            this.lblSunday.AutoSize = true;
            this.lblSunday.Location = new System.Drawing.Point(237, 418);
            this.lblSunday.Name = "lblSunday";
            this.lblSunday.Size = new System.Drawing.Size(21, 17);
            this.lblSunday.TabIndex = 7;
            this.lblSunday.Text = "7)";
            // 
            // lblSaturday
            // 
            this.lblSaturday.AutoSize = true;
            this.lblSaturday.Location = new System.Drawing.Point(237, 352);
            this.lblSaturday.Name = "lblSaturday";
            this.lblSaturday.Size = new System.Drawing.Size(21, 17);
            this.lblSaturday.TabIndex = 6;
            this.lblSaturday.Text = "6)";
            // 
            // lblFriday
            // 
            this.lblFriday.AutoSize = true;
            this.lblFriday.Location = new System.Drawing.Point(237, 286);
            this.lblFriday.Name = "lblFriday";
            this.lblFriday.Size = new System.Drawing.Size(21, 17);
            this.lblFriday.TabIndex = 5;
            this.lblFriday.Text = "5)";
            // 
            // lblThursday
            // 
            this.lblThursday.AutoSize = true;
            this.lblThursday.Location = new System.Drawing.Point(237, 226);
            this.lblThursday.Name = "lblThursday";
            this.lblThursday.Size = new System.Drawing.Size(21, 17);
            this.lblThursday.TabIndex = 4;
            this.lblThursday.Text = "4)";
            // 
            // lblWednesday
            // 
            this.lblWednesday.AutoSize = true;
            this.lblWednesday.Location = new System.Drawing.Point(237, 160);
            this.lblWednesday.Name = "lblWednesday";
            this.lblWednesday.Size = new System.Drawing.Size(21, 17);
            this.lblWednesday.TabIndex = 3;
            this.lblWednesday.Text = "3)";
            // 
            // lblTuesday
            // 
            this.lblTuesday.AutoSize = true;
            this.lblTuesday.Location = new System.Drawing.Point(237, 96);
            this.lblTuesday.Name = "lblTuesday";
            this.lblTuesday.Size = new System.Drawing.Size(21, 17);
            this.lblTuesday.TabIndex = 2;
            this.lblTuesday.Text = "2)";
            // 
            // lblMonday
            // 
            this.lblMonday.AutoSize = true;
            this.lblMonday.Location = new System.Drawing.Point(237, 30);
            this.lblMonday.Name = "lblMonday";
            this.lblMonday.Size = new System.Drawing.Size(21, 17);
            this.lblMonday.TabIndex = 1;
            this.lblMonday.Text = "1)";
            // 
            // btnAssign
            // 
            this.btnAssign.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssign.Location = new System.Drawing.Point(5, 194);
            this.btnAssign.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAssign.Name = "btnAssign";
            this.btnAssign.Size = new System.Drawing.Size(208, 75);
            this.btnAssign.TabIndex = 0;
            this.btnAssign.Text = "Assign randomly";
            this.btnAssign.UseVisualStyleBackColor = true;
            this.btnAssign.Click += new System.EventHandler(this.btnAssign_Click);
            // 
            // lblBack
            // 
            this.lblBack.AutoSize = true;
            this.lblBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lblBack.Location = new System.Drawing.Point(1108, 9);
            this.lblBack.Name = "lblBack";
            this.lblBack.Size = new System.Drawing.Size(56, 25);
            this.lblBack.TabIndex = 10;
            this.lblBack.Text = "Back";
            this.lblBack.Click += new System.EventHandler(this.lblBack_Click);
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(13, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(66, 17);
            this.lblWelcome.TabIndex = 2;
            this.lblWelcome.Text = "Welcome";
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1223, 602);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.lblBack);
            this.Controls.Add(this.tbRules);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "AdminForm";
            this.Text = "AdminForm";
            this.tbRules.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tpPendingAccounts.ResumeLayout(false);
            this.tpPendingAccounts.PerformLayout();
            this.tpTasks.ResumeLayout(false);
            this.tpTasks.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TabControl tbRules;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tpPendingAccounts;
        private System.Windows.Forms.Label lblRule;
        private System.Windows.Forms.TextBox tbAddRule;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.ListBox lbRules;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.TextBox tbEditRule;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEdit;
        private System.Windows.Forms.Label lblEdit;
        private System.Windows.Forms.Label lblBack;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.TabPage tpTasks;
        private System.Windows.Forms.Button btnAssign;
        private System.Windows.Forms.Label lblSunday;
        private System.Windows.Forms.Label lblSaturday;
        private System.Windows.Forms.Label lblFriday;
        private System.Windows.Forms.Label lblThursday;
        private System.Windows.Forms.Label lblWednesday;
        private System.Windows.Forms.Label lblTuesday;
        private System.Windows.Forms.Label lblMonday;
        private System.Windows.Forms.Label lblThisWeek;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbBannAccounts;
        private System.Windows.Forms.Button btnBann;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox lbBanned;
        private System.Windows.Forms.Button btnDenied;
        private System.Windows.Forms.Button btnApprove;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox lbPending;
    }
}